||READ ME||
CS 171 - A
Midterm Project - Snake Game Path Finder

For BFS:
With O as the starting position and X as the final state, edit the maze within the code and let the code run.
To be specific, the user must edit the part the maze that shows the outline of the maze (inside the Maze1 function)
After this just run the block of code

For DFS:
Run the 3rd block of code in the file
Input both start and end point values for both x and y, then let the code run.
After this, input the resulting x and y values of the path-finding coordinates
A graph then shows the direction of the path finder coordinates

If you have any questions, feel free to email us: erin.yabut@gmail.com or orlean.trinidad@gmail.com

||Erin Yabut & OJ Trinidad||